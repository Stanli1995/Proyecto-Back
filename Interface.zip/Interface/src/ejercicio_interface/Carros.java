package ejercicio_interface;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author stali
 */
public interface Carros {
    int marchas = 0;
    int Velocidad = 0;
    
    default void Imprimir(String texto){
        System.out.println("El carro Hyundai esta corriendo...."+ texto);
    }

    public void Velocidad();
    
}
