/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_interface;

/**
 *
 * @author stali
 */
public class Ejercicio_Interface  {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Hyundai Hyundai = new Hyundai(120,5);
        Hyundai Hyundai3 = new Hyundai(6);
        Hyundai Hyundai2 = new Hyundai();
       Ford Ford4 = new Ford();
       
        Hyundai2.Imprimir("Hyundai");
        Ford4.Imprimir("Hyundai");
        Hyundai.Velocidad();
        Hyundai3.Velocidad();
        
    }
}
