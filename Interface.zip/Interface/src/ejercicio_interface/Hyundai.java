package ejercicio_interface;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author stali
 */
public class Hyundai implements Carros {
    public int Velocidadd=0;
    public int Marchas=0;

    public Hyundai(int vel, int Marchas) {
        this.Velocidadd = vel;
        this.Marchas = Marchas;
    }
    
    public Hyundai (){
        
    }

    Hyundai(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Velocidad() {
        float tiempo;
        if ( Velocidadd <= Marchas){
            tiempo = Velocidadd + Marchas ;
            System.out.println("Cambio de Marchas: " + tiempo );
        }else{
            tiempo = Marchas  * Velocidadd;
            System.out.println("Cambio de Marchas: " + tiempo );
        } 
    }
    
}
