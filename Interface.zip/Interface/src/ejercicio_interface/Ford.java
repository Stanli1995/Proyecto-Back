package ejercicio_interface;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author stali
 */
public class Ford implements Carros {
    
    public int Velocidadd=0;
    public int Marchas=0;
    
    //constructor
    public Ford() {
    }
    //constructor para la sobrecarga
    public Ford(int velocidad) {
        this.Velocidadd=velocidad;
    }
    
    public Ford(int velocidad, int Marchas) {
        this.Velocidadd = velocidad;
        this.Marchas = Marchas;
    }
    
    //sobrecarga de metodos
    public void Velocidad(double tiempo) {
        //double tiempo;
        if ( Velocidadd >= Marchas){
            tiempo = Marchas + Velocidadd;
            System.out.println("Cambio de Marchas: " + tiempo );
        }else{
            tiempo = Marchas * Velocidadd;
            System.out.println("Cambio de Marchas: " + tiempo );
        } 
    }
    
    @Override
    public void Velocidad() {
        double tiempo;
        if ( Velocidadd >= Marchas){
            tiempo = Marchas + Velocidadd;
            System.out.println("Cambio de Marchas: " + tiempo );
        }else{
            tiempo = Marchas * Velocidadd;
            System.out.println("Cambio de Marchas: " + tiempo );
        } 
    }
    
    

}
