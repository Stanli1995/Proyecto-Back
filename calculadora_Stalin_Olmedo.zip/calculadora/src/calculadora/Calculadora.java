/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;

import java.util.Scanner;

/**
 *
 * @author stalin Olmedo 
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner leer = new Scanner (System.in);
       
        System.out.println(" Ingresar Primer Número ");
        //int a = leer.nextInt();
        double a = leer.nextDouble();
        
        System.out.println(" Ingresar Segúndo Número ");
        
        //int b = leer.nextInt();
        double b = leer.nextDouble();
        
        //int suma = a + b;
        double suma = a + b;
        
        //int resta = a - b;
        double resta = a - b;
        
        //int multiplicacion = a * b;
        double multiplicacion = a * b;
        
        //int division = a / b;
        double division = a / b;
        
        System.out.println("La Suma  es: " + suma);
        System.out.println("La Resta es: " + resta);
        System.out.println("La Multiplicacion es: " + multiplicacion);
        System.out.println("La Division es: " + division);
    }
    
}
