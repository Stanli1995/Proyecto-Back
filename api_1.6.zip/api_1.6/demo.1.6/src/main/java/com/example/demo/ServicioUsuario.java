package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/servicesREST")

public class ServicioUsuario {

    @RequestMapping(method = RequestMethod.GET, produces = " application/Json", path = "/getUsuario")
    public @ResponseBody Modelorespon getUsuario(){
        Modelorespon respuesta = new  Modelorespon();
        respuesta.setcode(200);
        respuesta.setid(1);
        respuesta.setnombre("java Revolutions");
        respuesta.setstatus(true);
        return respuesta;
    }

}
