package com.example.demo;

public class Modelorespon {
    private int id ;
    private  String nombre;
    private boolean status;
    private int code;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setcode(int i) {
    }

    public void setid(int i) {
    }

    public void setnombre(String java_revolutions) {
    }

    public void setstatus(boolean b) {
    }
}
